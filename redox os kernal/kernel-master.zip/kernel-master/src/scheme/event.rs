use alloc::sync::Arc;
use syscall::{EventFlags, O_NONBLOCK};

use crate::{
    context::file::InternalFlags,
    event::{next_queue_id, queues, queues_mut, EventQueue, EventQueueId},
    sync::CleanLockToken,
    syscall::{
        data::Event,
        error::*,
        usercopy::{UserSliceRo, UserSliceWo},
    },
};

use super::{CallerCtx, KernelScheme, OpenResult, StrOrBytes};

const SCHEME_ROOT_ID: usize = usize::MAX;

pub struct EventScheme;

impl KernelScheme for EventScheme {
    fn scheme_root(&self, _token: &mut CleanLockToken) -> Result<usize> {
        Ok(SCHEME_ROOT_ID)
    }
    fn kopenat(
        &self,
        id: usize,
        _user_buf: StrOrBytes,
        _flags: usize,
        _fcntl_flags: u32,
        _ctx: CallerCtx,
        token: &mut CleanLockToken,
    ) -> Result<OpenResult> {
        if id != SCHEME_ROOT_ID {
            return Err(Error::new(EACCES));
        }
        let id = next_queue_id();
        queues_mut(token.token()).insert(id, Arc::new(EventQueue::new(id)));

        Ok(OpenResult::SchemeLocal(id.get(), InternalFlags::empty()))
    }

    fn close(&self, id: usize, token: &mut CleanLockToken) -> Result<()> {
        let id = EventQueueId::from(id);
        let queue = queues_mut(token.token())
            .remove(&id)
            .ok_or(Error::new(EBADF))?;
        if let Some(queue) = Arc::into_inner(queue) {
            queue.into_drop(token.downgrade());
        }
        Ok(())
    }

    fn kread(
        &self,
        id: usize,
        buf: UserSliceWo,
        flags: u32,
        _stored_flags: u32,
        token: &mut CleanLockToken,
    ) -> Result<usize> {
        let id = EventQueueId::from(id);

        let queue = {
            let handles = queues(token.token());
            let handle = handles.get(&id).ok_or(Error::new(EBADF))?;
            handle.clone()
        };

        queue.read(buf, flags & O_NONBLOCK as u32 == 0, token)
    }

    fn kwrite(
        &self,
        id: usize,
        buf: UserSliceRo,
        _flags: u32,
        _stored_flags: u32,
        token: &mut CleanLockToken,
    ) -> Result<usize> {
        let id = EventQueueId::from(id);

        let queue = {
            let handles = queues(token.token());
            let handle = handles.get(&id).ok_or(Error::new(EBADF))?;
            handle.clone()
        };
        let mut events_written = 0;

        for chunk in buf.in_exact_chunks(size_of::<Event>()) {
            let event = unsafe { chunk.read_exact::<Event>()? };
            if queue.write(&[event], token)? == 0 {
                break;
            }
            events_written += 1;
        }

        Ok(events_written * size_of::<Event>())
    }

    fn kfpath(&self, _id: usize, buf: UserSliceWo, _token: &mut CleanLockToken) -> Result<usize> {
        buf.copy_common_bytes_from_slice(b"/scheme/event/")
    }

    fn fevent(
        &self,
        id: usize,
        flags: EventFlags,
        token: &mut CleanLockToken,
    ) -> Result<EventFlags> {
        let id = EventQueueId::from(id);

        let queue = {
            let handles = queues(token.token());
            let handle = handles.get(&id).ok_or(Error::new(EBADF))?;
            handle.clone()
        };

        let mut ready = EventFlags::empty();
        if flags.contains(EventFlags::EVENT_WRITE) {
            // It is always possible to write events
            ready |= EventFlags::EVENT_WRITE;
        }
        if flags.contains(EventFlags::EVENT_READ) && !queue.is_currently_empty(token) {
            // It is possible to read if queue is not empty
            ready |= EventFlags::EVENT_READ;
        }
        Ok(ready)
    }
}
